<?php
//decode by Www.Mobanzhu.Com
//模板著承接PHP开发定制,软件开发定制，PHP解密
defined("IN_IA") or exit("Access Denied");
class Vp_phModuleProcessor extends WeModuleProcessor
{
    public function respond()
    {
        global $_W;
    }
}